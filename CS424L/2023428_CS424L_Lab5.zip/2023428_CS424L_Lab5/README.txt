CS424L Compiler Construction Lab - Lab 5 (Syntax Trees and Intermediate Code Generation)
Muhammad Haris | BSCS-2023 | Reg no: 2023428

Report/          Lab 5 report (Word + PDF) in the submission format
Code/example/    handout example (ast.h, predictive.l) and its inputs
Code/            exercise: ast.h and task1_loops.l (adds while and do-while)
Code/tests/      test inputs
Screenshots/     terminal output of every run

Build and run:
    cd Code
    flex -o lex.yy.cpp task1_loops.l
    g++ lex.yy.cpp -o task1
    ./task1 tests/loops.txt
    ./task1 -t tests/loops.txt      (also prints the syntax tree)
