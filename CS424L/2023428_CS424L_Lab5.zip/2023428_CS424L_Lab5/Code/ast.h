// ast.h for Lab 5 exercise - Muhammad Haris 2023428
// based on the handout ast.h. changes:
//  - new classes while_stmt and do_stmt (made by looking at if_stmt)
//  - labels are printed on their own line (".L0:")
//  - every node has print() so the syntax tree can be shown with -t
#include <string>
#include <iostream>
#include <cstdlib>
#include <sstream>
using namespace std;

namespace ast {

int t_idx = 0;
string temp() {
    stringstream ss;
    ss << ".t" << t_idx++;
    return ss.str();
}

int l_idx = 0;
string label() {
    stringstream ss;
    ss << ".L" << l_idx++;
    return ss.str();
}

void tab(int d) { for (int i = 0; i < d; i++) cout << "|   "; }

class node {
public:
    virtual void print(int d) = 0;
};

class stmt : public node {
public:
    virtual void gen() {}
};

class expr : public node {
public:
    virtual expr* lvalue() {
        cerr << "Error: invalid lvalue\n";
        exit(1);
    }
    virtual expr* rvalue() { return this; }
    virtual string str() { return "Not implemented"; }
};

// if (e) s
class if_stmt : public stmt {
public:
    expr *left;
    stmt *right;
    string l;
    if_stmt(expr* e, stmt* s) : left(e), right(s) {
        l = label();
    }
    void gen() {
        expr* e = left->rvalue();
        cout << "ifFalse " << e->str() << " goto " << l << "\n";
        right->gen();
        cout << l << ":\n";
    }
    void print(int d) {
        tab(d); cout << "if" << endl;
        left->print(d + 1);
        right->print(d + 1);
    }
};

// while (e) s
//   begin:
//     ifFalse e goto after
//     s
//     goto begin
//   after:
class while_stmt : public stmt {
public:
    expr *cond;
    stmt *body;
    string begin, after;
    while_stmt(expr* e, stmt* s) : cond(e), body(s) {
        begin = label();
        after = label();
    }
    void gen() {
        cout << begin << ":\n";
        expr* e = cond->rvalue();
        cout << "ifFalse " << e->str() << " goto " << after << "\n";
        body->gen();
        cout << "goto " << begin << "\n";
        cout << after << ":\n";
    }
    void print(int d) {
        tab(d); cout << "while" << endl;
        cond->print(d + 1);
        body->print(d + 1);
    }
};

// do s while (e);
//   begin:
//     s
//     if e goto begin
class do_stmt : public stmt {
public:
    stmt *body;
    expr *cond;
    string begin;
    do_stmt(stmt* s, expr* e) : body(s), cond(e) {
        begin = label();
    }
    void gen() {
        cout << begin << ":\n";
        body->gen();
        expr* e = cond->rvalue();
        cout << "if " << e->str() << " goto " << begin << "\n";
    }
    void print(int d) {
        tab(d); cout << "do-while" << endl;
        body->print(d + 1);
        cond->print(d + 1);
    }
};

class eval : public stmt {
public:
    expr* left;
    eval(expr* e) : left(e) {}
    void gen() { left->rvalue(); }
    void print(int d) {
        tab(d); cout << "eval" << endl;
        left->print(d + 1);
    }
};

class seq : public stmt {
public:
    stmt* left;
    stmt* right;
    seq(stmt* l, stmt* r) : left(l), right(r) {}
    void gen() {
        left->gen();
        if (right) right->gen();
    }
    void print(int d) {
        // a chain of seq nodes is shown as one list, it is easier to read
        tab(d); cout << "seq" << endl;
        for (seq* s = this; s != NULL; ) {
            s->left->print(d + 1);
            seq* next = dynamic_cast<seq*>(s->right);
            if (next == NULL && s->right != NULL) { s->right->print(d + 1); }
            s = next;
        }
    }
};

class assign : public expr {
public:
    expr *left, *right;
    assign(expr* l, expr* r) : left(l), right(r) {}
    expr* rvalue() {
        expr* l = left->lvalue();
        expr* r = right->rvalue();
        cout << l->str() << "=" << r->str() << "\n";
        return r;
    }
    void print(int d) {
        tab(d); cout << "=" << endl;
        left->print(d + 1);
        right->print(d + 1);
    }
};

class id : public expr {
public:
    string lexeme;
    id(string name) : lexeme(name) {}
    expr* lvalue() { return this; }
    string str() { return lexeme; }
    void print(int d) { tab(d); cout << "id " << lexeme << endl; }
};

class num : public expr {
public:
    int value;
    num(int n) : value(n) {}
    string str() {
        stringstream t;
        t << value;
        return t.str();
    }
    void print(int d) { tab(d); cout << "num " << value << endl; }
};

}
