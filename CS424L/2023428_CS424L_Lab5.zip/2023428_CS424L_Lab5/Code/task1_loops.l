/* Lab 5 Task 1 - Muhammad Haris 2023428
   the handout's predictive parser + syntax tree, with while and do-while.

   grammar (new rules marked with *):
     program -> block
     block   -> { stmts }
     stmts   -> stmt stmts | e
     stmt    -> expr ;
              | if ( expr ) stmt
            * | while ( expr ) stmt
            * | do stmt while ( expr ) ;
              | block
     expr    -> rel r'
     r'      -> = expr | e
     rel     -> factor
     factor  -> id | num

   translation scheme for the new rules:
     stmt -> while ( expr ) stmt1          {stmt.n = new while_stmt(expr.n, stmt1.n)}
     stmt -> do stmt1 while ( expr ) ;     {stmt.n = new do_stmt(stmt1.n, expr.n)}

   other fixes to the handout code:
     - stmts did not continue after a nested block ({ {a=1;} b=2; } gave a
       syntax error). now a block is parsed through stmt() like the others
     - functions return NULL after error() so g++ does not warn
     - error() also says which token was found

   run: flex -o lex.yy.cpp task1_loops.l, g++ lex.yy.cpp -o task1, ./task1 [-t] file.txt
   -t prints the syntax tree before the code */
%option noyywrap
%{
#include <iostream>
#include <cstdlib>
#include <cstring>
#include "ast.h"
using namespace std;

const int T_IF = 310;
const int T_WHILE = 311;
const int T_DO = 312;
const int T_ID = 350;
const int T_NUM = 360;

int lookahead;
int line = 1;

void match(int);
void error();
ast::stmt* stmts();
ast::stmt* stmt();
ast::stmt* program();
ast::stmt* block();
ast::expr* expr();
ast::expr* factor();
ast::expr* rel();
ast::expr* rp();
%}

alpha       [a-zA-Z_]
alphanum    [0-9a-zA-Z_]
digit       [0-9]

%%
[ \t\r]+                ;
\n                      { line++; }
if                      { return T_IF; }
while                   { return T_WHILE; }
do                      { return T_DO; }
{alpha}{alphanum}*      { return T_ID; }
{digit}+                { return T_NUM; }
.                       { return *yytext; }
%%

int main(int argc, char* argv[])
{
    bool show_tree = false;
    int arg = 1;
    if (argc > 1 && strcmp(argv[1], "-t") == 0) { show_tree = true; arg++; }
    if (argc > arg) {
        yyin = fopen(argv[arg], "r");
        if (!yyin) { perror(argv[arg]); return 1; }
    }
    lookahead = yylex();
    ast::stmt* s = program();
    if (lookahead)
        error();
    if (s == NULL) return 0;            // empty program {}
    if (show_tree) {
        cout << "syntax tree:" << endl;
        s->print(0);
        cout << endl << "code:" << endl;
    }
    s->gen();
    return 0;
}

ast::stmt* program() {
    return block();
}

ast::stmt* block() {
    if (lookahead == '{') {
        ast::stmt* s;
        match('{'); s = stmts(); match('}');
        return s;
    }
    error();
    return NULL;
}

// stmts -> stmt stmts | e
// FIRST(stmt) is id, num, if, while, do, {     FOLLOW(stmts) is }
ast::stmt* stmts() {
    switch (lookahead) {
        case T_ID:
        case T_NUM:
        case T_IF:
        case T_WHILE:
        case T_DO:
        case '{': {
            ast::stmt* l = stmt();
            ast::stmt* r = stmts();
            if (l == NULL) return r;         // an empty block {} gives no code
            return new ast::seq(l, r);
        }
        default:
            return NULL;
    }
}

ast::stmt* stmt() {
    ast::expr* e;
    ast::stmt* s;
    switch (lookahead) {
        case T_ID:
        case T_NUM:
            e = expr(); match(';');
            return new ast::eval(e);
        case T_IF:
            match(T_IF); match('('); e = expr(); match(')'); s = stmt();
            return new ast::if_stmt(e, s);
        case T_WHILE:
            match(T_WHILE); match('('); e = expr(); match(')'); s = stmt();
            return new ast::while_stmt(e, s);
        case T_DO:
            match(T_DO); s = stmt(); match(T_WHILE); match('('); e = expr(); match(')'); match(';');
            return new ast::do_stmt(s, e);
        case '{':
            return block();
        default:
            error();
            return NULL;
    }
}

// expr -> rel rp
ast::expr* expr() {
    ast::expr *left, *right;
    switch (lookahead) {
        case T_ID:
        case T_NUM:
            left = rel(); right = rp();
            if (right == NULL)
                return left;
            return new ast::assign(left, right);
        default:
            error();
            return NULL;
    }
}

// rp -> = expr | epsilon       FOLLOW(rp) is ), ;
ast::expr* rp() {
    switch (lookahead) {
        case '=':
            match('=');
            return expr();
        case ')':
        case ';':
            return NULL;
        default:
            error();
            return NULL;
    }
}

ast::expr* rel() {
    return factor();
}

ast::expr* factor() {
    string name(yytext);
    switch (lookahead) {
        case T_ID:
            match(T_ID);
            return new ast::id(name);
        case T_NUM: {
            int value = atoi(yytext);
            match(T_NUM);
            return new ast::num(value);
        }
        default:
            error();
            return NULL;
    }
}

void match(int terminal) {
    if (lookahead == terminal)
        lookahead = yylex();
    else
        error();
}

void error() {
    cout << "syntax error on line " << line << " at '" << (lookahead ? yytext : "end of file") << "'\n";
    exit(1);
}
