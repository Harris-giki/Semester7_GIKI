/* Lab 4 Task 1 - Muhammad Haris 2023428
   assignment statements from lab 3 with declarations and nested scopes.

   grammar:
     program -> block
     block   -> { decls stmts }
     decls   -> decl decls | e
     decl    -> type id ;
     stmts   -> stmt stmts | e
     stmt    -> block | id = expr ;
     expr    -> term expr'
     expr'   -> + term expr' | e
     term    -> factor term'
     term'   -> * factor term' | e
     factor  -> id | num | ( expr )

   translation scheme (actions in braces):
     block  -> { {saved = top; top = new sym_tab(top)} decls stmts } {delete top; top = saved}
     decl   -> type id ; {if (!top.put(id, type)) error "multiple declarations"}
     stmt   -> id {if (!top.get(id)) error "undeclared"} = expr ;
     factor -> id {if (!top.get(id)) error "undeclared"} | num | ( expr )

   output: the program is printed back with every variable written as
   name:type(sN) where N is the scope level of the declaration it uses.
   multiple declarations and undeclared variables are listed at the end,
   the translation does not stop for them. a syntax error stops the program.

   run: flex -o lex.yy.cpp task1_scopes.l, g++ lex.yy.cpp -o task1, ./task1 file.txt */
%option noyywrap
%option yylineno

%{
#include <cstdlib>
#include <cstdio>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include "symtab.h"
using namespace std;

const int T_TYPE = 350;
const int T_ID   = 351;
const int T_NUM  = 352;

int lookahead;
sym_tab* top = NULL;
vector<string> errors;   /* semantic errors, printed after the translation */

void block(); void decls(); void decl(); void stmts(); void stmt();
void expr(); void expr_rest(); void term(); void term_rest(); void factor();
%}

letter  [A-Za-z_]
digit   [0-9]

%%
[ \t\r\n]+                  ;
"//".*                      ;
int|float|bool|char         { return T_TYPE; }
{letter}({letter}|{digit})* { return T_ID; }
{digit}+                    { return T_NUM; }
.                           { return *yytext; }
%%

void indent() {
    int n = (top == NULL) ? 0 : top->level;
    for (int i = 0; i < n; i++) cout << "    ";
}

void error() {
    cout << "line " << yylineno << ": syntax error at '" << (lookahead ? yytext : "end of file") << "'" << endl;
    exit(1);
}

void match(int t) {
    if (lookahead == t) lookahead = yylex();
    else error();
}

/* prints a variable use, or reports it if it was never declared */
void use(string id, int line) {
    sym_ent* s = top->get(id);
    if (s == NULL) {
        cout << id << ":??";
        stringstream m;
        m << "line " << line << ": undeclared variable " << id;
        errors.push_back(m.str());
    } else {
        cout << id << ":" << s->type << "(s" << s->level << ")";
    }
}

void program() {
    top = NULL;
    block();
}

void block() {
    if (lookahead != '{') error();
    indent(); cout << "{" << endl;
    match('{');
    sym_tab* saved = top;          /* new scope */
    top = new sym_tab(top);
    decls();
    stmts();
    if (lookahead != '}') error();
    delete top;                    /* leave scope */
    top = saved;
    indent(); cout << "}" << endl;
    match('}');
}

void decls() {
    if (lookahead == T_TYPE) { decl(); decls(); }
}

void decl() {
    string type(yytext);
    match(T_TYPE);
    string id(yytext);
    int line = yylineno;
    match(T_ID);
    match(';');
    sym_ent* s = new sym_ent;
    s->type = type;
    s->line = line;
    if (!top->put(id, s)) {
        sym_ent* old = top->get_here(id);
        stringstream m;
        m << "line " << line << ": multiple declarations of " << id
          << " (already declared as " << old->type << " on line " << old->line << ")";
        errors.push_back(m.str());
        delete s;
    } else {
        indent(); cout << type << " " << id << ";" << endl;
    }
}

void stmts() {
    if (lookahead == '{' || lookahead == T_ID) { stmt(); stmts(); }
}

void stmt() {
    if (lookahead == '{') {
        block();
    } else if (lookahead == T_ID) {
        string id(yytext);
        int line = yylineno;
        match(T_ID);
        indent(); use(id, line);
        match('='); cout << " = ";
        expr();
        match(';'); cout << ";" << endl;
    } else {
        error();
    }
}

void expr()      { term(); expr_rest(); }
void expr_rest() { if (lookahead == '+') { match('+'); cout << " + "; term(); expr_rest(); } }
void term()      { factor(); term_rest(); }
void term_rest() { if (lookahead == '*') { match('*'); cout << " * "; factor(); term_rest(); } }

void factor() {
    if (lookahead == T_ID) {
        string id(yytext);
        int line = yylineno;
        match(T_ID);
        use(id, line);
    } else if (lookahead == T_NUM) {
        cout << yytext;
        match(T_NUM);
    } else if (lookahead == '(') {
        match('('); cout << "(";
        expr();
        match(')'); cout << ")";
    } else {
        error();
    }
}

int main(int argc, char* argv[]) {
    if (argc == 2) {
        yyin = fopen(argv[1], "r");
        if (!yyin) { perror(argv[1]); return 1; }
    }
    lookahead = yylex();
    program();
    if (lookahead) error();      /* something after the last } */
    cout << endl << errors.size() << " error(s)" << endl;
    for (size_t i = 0; i < errors.size(); i++)
        cout << "  " << errors[i] << endl;
    return 0;
}
