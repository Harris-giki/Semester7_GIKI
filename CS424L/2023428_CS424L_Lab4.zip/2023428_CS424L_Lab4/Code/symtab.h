// symtab.h for Lab 4 exercise - Muhammad Haris 2023428
// same idea as the handout (one map per scope, chained with prev) but each
// entry also remembers the line it was declared on and the scope level,
// so the output can show which declaration a variable belongs to.
#include <iostream>
#include <string>
#include <map>
using namespace std;

struct sym_ent {
    string type;
    int line;     // line of the declaration
    int level;    // 1 = outer block, 2 = block inside it, ...
};

class sym_tab {
public:
    map<string, sym_ent*> table;
    sym_tab* prev;
    int level;

    sym_tab(sym_tab* p) {
        prev = p;
        level = (p == NULL) ? 1 : p->level + 1;
    }

    // returns false if the name is already in THIS scope
    bool put(string s, sym_ent* sym) {
        if (table.count(s) == 0) {
            sym->level = level;
            table[s] = sym;
            return true;
        }
        return false;
    }

    // only looks in this scope (used for the error message)
    sym_ent* get_here(string s) {
        if (table.count(s) > 0) return table[s];
        return NULL;
    }

    // looks in this scope and then all the outer ones
    sym_ent* get(string s) {
        for (sym_tab* i = this; i != NULL; i = i->prev) {
            if (i->table.count(s) > 0)
                return i->table[s];
        }
        return NULL;
    }

    ~sym_tab() {
        for (map<string, sym_ent*>::iterator x = table.begin(); x != table.end(); x++)
            delete x->second;
    }
};
