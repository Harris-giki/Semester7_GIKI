CS424L Compiler Construction Lab - Lab 4 (Lexical Analyzers and Symbol Tables)
Muhammad Haris | BSCS-2023 | Reg no: 2023428

Report/          Lab 4 report (Word + PDF) in the submission format
Code/example/    handout example (symtab.h, translator.l) and its inputs
Code/            exercise: symtab.h and task1_scopes.l
Code/tests/      test inputs
Screenshots/     terminal output of every run

Build and run:
    cd Code
    flex -o lex.yy.cpp task1_scopes.l
    g++ lex.yy.cpp -o task1
    ./task1 tests/valid.txt
