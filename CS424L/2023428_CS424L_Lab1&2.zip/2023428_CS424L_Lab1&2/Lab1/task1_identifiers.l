/* Lab 1 Task 1 - Muhammad Haris 2023428
   finds all names/identifiers in a C or java file and the line
   where each one was first found
   run: flex task1_identifiers.l, gcc lex.yy.c -o task1, ./task1 file.c */
%option noyywrap
%option yylineno

%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NAMES 2048

/* table of names already seen, with the line of first occurrence */
char *names[MAX_NAMES];
int   first_line[MAX_NAMES];
int   count = 0;

/* add the name if it is new; ignore it if we have seen it before */
void record(const char *name, int line) {
    for (int i = 0; i < count; i++)
        if (strcmp(names[i], name) == 0)
            return;
    if (count < MAX_NAMES) {
        names[count] = strdup(name);
        first_line[count] = line;
        count++;
    }
}
%}

LETTER  [a-zA-Z_$]
DIGIT   [0-9]

%%
"//".*                          { /* skip single-line comment */ }
"/*"([^*]|\*+[^*/])*\*+"/"      { /* skip block comment */ }
\"(\\.|[^\\"\n])*\"             { /* skip string literal */ }
\'(\\.|[^\\'\n])*\'             { /* skip char literal */ }
{DIGIT}+({LETTER}|{DIGIT})*     { /* a number (maybe with suffix), not a name */ }
{LETTER}({LETTER}|{DIGIT})*     { record(yytext, yylineno); }
.|\n                            { /* ignore everything else */ }
%%

int main(int argc, char *argv[]) {
    if (argc == 2) {
        yyin = fopen(argv[1], "r");
        if (!yyin) { perror(argv[1]); return 1; }
    }
    yylex();

    printf("%-20s %s\n", "NAME", "FIRST FOUND ON LINE");
    printf("%-20s %s\n", "----", "-------------------");
    for (int i = 0; i < count; i++)
        printf("%-20s %d\n", names[i], first_line[i]);
    printf("\nTotal distinct names: %d\n", count);
    return 0;
}
