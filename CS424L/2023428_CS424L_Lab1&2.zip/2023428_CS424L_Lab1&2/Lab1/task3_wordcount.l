/* Lab 1 Task 3 - Muhammad Haris 2023428
   counts characters, words and lines in a text file (like wc)
   run: flex task3_wordcount.l, gcc lex.yy.c -o task3, ./task3 file.txt */
%option noyywrap

%{
#include <stdio.h>
int chars = 0, words = 0, lines = 0;
%}

%%
[^ \t\n]+   { words++; chars += yyleng; }
\n          { lines++; chars++; }
.           { chars++;  /* space or tab */ }
%%

int main(int argc, char *argv[]) {
    if (argc == 2) {
        yyin = fopen(argv[1], "r");
        if (!yyin) { perror(argv[1]); return 1; }
    }
    yylex();
    printf("Characters : %d\n", chars);
    printf("Words      : %d\n", words);
    printf("Lines      : %d\n", lines);
    return 0;
}
