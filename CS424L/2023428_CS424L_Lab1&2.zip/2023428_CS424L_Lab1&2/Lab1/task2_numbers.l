/* Lab 1 Task 2 - Muhammad Haris 2023428
   prints all numeric constants in a file (123, 123.10, -1234 etc)
   run: flex task2_numbers.l, gcc lex.yy.c -o task2, ./task2 file.c */
%option noyywrap
%option yylineno

%{
#include <stdio.h>
int found = 0;

void report(const char *kind) {
    found++;
    printf("Line %-4d %-10s %s\n", yylineno, kind, yytext);
}
%}

DIGIT   [0-9]
INT     {DIGIT}+
EXP     [eE][+-]?{DIGIT}+

%%
"//".*                          { /* skip comment */ }
"/*"([^*]|\*+[^*/])*\*+"/"      { /* skip comment */ }
\"(\\.|[^\\"\n])*\"             { /* skip string literal */ }
[a-zA-Z_][a-zA-Z0-9_]*          { /* identifier: digits inside are not constants */ }

0[xX][0-9a-fA-F]+               { report("HEX"); }
-?{INT}"."{DIGIT}*{EXP}?[fF]?   { report("FLOAT"); }
-?"."{DIGIT}+{EXP}?[fF]?        { report("FLOAT"); }
-?{INT}{EXP}[fF]?               { report("FLOAT"); }
-?{INT}[lL]?                    { report("INTEGER"); }

.|\n                            { /* ignore */ }
%%

int main(int argc, char *argv[]) {
    if (argc == 2) {
        yyin = fopen(argv[1], "r");
        if (!yyin) { perror(argv[1]); return 1; }
    }
    printf("%-9s %-10s %s\n", "LINE", "TYPE", "CONSTANT");
    yylex();
    printf("\nTotal numerical constants found: %d\n", found);
    return 0;
}
