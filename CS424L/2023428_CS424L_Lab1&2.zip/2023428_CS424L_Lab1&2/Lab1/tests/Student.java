// Simple Java class for testing
public class Student {
    private String name;
    private int regNo;

    public Student(String name, int regNo) {
        this.name = name;
        this.regNo = regNo;
    }

    public double gpa(double[] grades) {
        double total = 0.0;
        for (double g : grades) total += g;
        return total / grades.length;
    }

    public static void main(String[] args) {
        Student s = new Student("Haris", 2023428);
        System.out.println(s.gpa(new double[]{3.7, 3.9, -0.5}));
    }
}
