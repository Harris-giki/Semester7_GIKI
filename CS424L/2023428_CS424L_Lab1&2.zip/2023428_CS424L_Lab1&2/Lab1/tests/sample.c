#include <stdio.h>

// compute the average of some marks
float average(int marks[], int n) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum = sum + marks[i];
    }
    /* integer division avoided */
    return (float) sum / n;
}

int main() {
    int marks[5] = {78, 92, 65, 88, 100};
    int count2 = 5;
    float avg = average(marks, count2);
    double rate = 123.10, offset = -1234, tiny = 1.5e-3;
    if (avg >= 80.5 && rate != 0) {
        printf("Grade A: %f\n", avg);
    } else {
        printf("Keep going\n");
    }
    return 0;
}
