/* Lab 1 Task 4 - Muhammad Haris 2023428
   converts C code into tokens, e.g. if (a<b) gives <IF><LPAREN><ID><LT><ID><RPAREN>
   whitespace and comments are skipped
   run: flex task4_tokenizer.l, gcc lex.yy.c -o task4, ./task4 file.c */
%option noyywrap

%{
#include <stdio.h>
#include <ctype.h>

/* print <NAME> for a token */
#define TOK(name) printf("<%s>", name)
%}

DIGIT   [0-9]
LETTER  [a-zA-Z_]
ID      {LETTER}({LETTER}|{DIGIT})*

%%
"//".*          { /* ignore comment */ }
"/*"([^*]|\*+[^*/])*\*+"/"   { /* ignore block comment */ }
^[ \t]*#.*      { TOK("PREPROCESSOR"); }
[ \t\r]+        { /* ignore whitespace */ }
\n              { printf("\n"); }

 /* keywords */
"if"            { TOK("IF"); }
"else"          { TOK("ELSE"); }
"while"         { TOK("WHILE"); }
"for"           { TOK("FOR"); }
"do"            { TOK("DO"); }
"return"        { TOK("RETURN"); }
"break"         { TOK("BREAK"); }
"continue"      { TOK("CONTINUE"); }
"int"           { TOK("INT"); }
"float"         { TOK("FLOAT"); }
"double"        { TOK("DOUBLE"); }
"char"          { TOK("CHAR"); }
"void"          { TOK("VOID"); }
"long"          { TOK("LONG"); }
"short"         { TOK("SHORT"); }
"unsigned"      { TOK("UNSIGNED"); }
"const"         { TOK("CONST"); }
"struct"        { TOK("STRUCT"); }
"switch"        { TOK("SWITCH"); }
"case"          { TOK("CASE"); }
"default"       { TOK("DEFAULT"); }
"sizeof"        { TOK("SIZEOF"); }

 /* identifiers and literals */
{ID}                        { TOK("ID"); }
{DIGIT}+"."{DIGIT}+([eE][+-]?{DIGIT}+)?   { TOK("FLOAT_NUM"); }
{DIGIT}+                    { TOK("NUM"); }
\"(\\.|[^\\"\n])*\"         { TOK("STRING"); }
\'(\\.|[^\\'\n])\'          { TOK("CHAR_LIT"); }

 /* operators */
"<="            { TOK("LE"); }
">="            { TOK("GE"); }
"=="            { TOK("EQ"); }
"!="            { TOK("NE"); }
"<"             { TOK("LT"); }
">"             { TOK("GT"); }
"="             { TOK("ASSIGN"); }
"++"            { TOK("INC"); }
"--"            { TOK("DEC"); }
"+"             { TOK("PLUS"); }
"-"             { TOK("MINUS"); }
"*"             { TOK("MULT"); }
"/"             { TOK("DIV"); }
"%"             { TOK("MOD"); }
"&&"            { TOK("AND"); }
"||"            { TOK("OR"); }
"!"             { TOK("NOT"); }
"+="            { TOK("PLUS_ASSIGN"); }
"-="            { TOK("MINUS_ASSIGN"); }

 /* punctuation */
"("             { TOK("LPAREN"); }
")"             { TOK("RPAREN"); }
"{"             { TOK("LBRACE"); }
"}"             { TOK("RBRACE"); }
"["             { TOK("LBRACKET"); }
"]"             { TOK("RBRACKET"); }
";"             { TOK("SEMI"); }
","             { TOK("COMMA"); }
"."             { TOK("DOT"); }
"&"             { TOK("AMPERSAND"); }

.               { printf("<UNKNOWN:%s>", yytext); }
%%

int main(int argc, char *argv[]) {
    if (argc == 2) {
        yyin = fopen(argv[1], "r");
        if (!yyin) { perror(argv[1]); return 1; }
    }
    yylex();
    return 0;
}
