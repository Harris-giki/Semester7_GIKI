CS424L Compiler Construction Lab - Lab 1 & Lab 2
Muhammad Haris | BSCS-2023 | Reg no: 2023428

Reports/      Lab 1 and Lab 2 reports (Word + PDF) in the submission format
Lab1/         Flex sources for Lab 1 tasks 1-4, with test inputs in Lab1/tests
Lab2/         Flex sources for Lab 2 tasks 1-3, with test inputs in Lab2/tests
Screenshots/  Terminal output of every task

Build and run any task, e.g.:
    cd Lab1
    flex task1_identifiers.l
    gcc lex.yy.c -o task1
    ./task1 tests/sample.c
