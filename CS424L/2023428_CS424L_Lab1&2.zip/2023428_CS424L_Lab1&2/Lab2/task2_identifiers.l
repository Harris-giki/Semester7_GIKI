/* Lab 2 Task 2 - Muhammad Haris 2023428
   finds identifiers (variables, functions, classes) in a C or java file
   with the line where they first appear and how many times they are used.
   comments, strings and whitespace are removed and keywords are not counted
   run: flex task2_identifiers.l, gcc lex.yy.c -o task2, ./task2 file.java */
%option noyywrap
%option yylineno

%x COMMENT

%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_IDS 2048

char *ids[MAX_IDS];
int   first_line[MAX_IDS];
int   uses[MAX_IDS];
int   count = 0;
int   comment_start = 0;

/* reserved words of C and Java: these are not identifiers */
const char *keywords[] = {
    "auto","break","case","char","const","continue","default","do","double",
    "else","enum","extern","float","for","goto","if","int","long","register",
    "return","short","signed","sizeof","static","struct","switch","typedef",
    "union","unsigned","void","volatile","while","inline","restrict","bool",
    "abstract","assert","boolean","byte","catch","class","extends","final",
    "finally","implements","import","instanceof","interface","native","new",
    "package","private","protected","public","super","synchronized","this",
    "throw","throws","transient","try","true","false","null","var",
    NULL
};

int is_keyword(const char *s) {
    for (int i = 0; keywords[i]; i++)
        if (strcmp(keywords[i], s) == 0) return 1;
    return 0;
}

void record(const char *name, int line) {
    if (is_keyword(name)) return;
    for (int i = 0; i < count; i++)
        if (strcmp(ids[i], name) == 0) { uses[i]++; return; }
    if (count < MAX_IDS) {
        ids[count] = strdup(name);
        first_line[count] = line;
        uses[count] = 1;
        count++;
    }
}
%}

LETTER  [a-zA-Z_$]
DIGIT   [0-9]

%%
"/*"                    { comment_start = yylineno; BEGIN(COMMENT); }
<COMMENT>"*/"           { BEGIN(INITIAL); }
<COMMENT>.|\n           { /* remove comment text */ }
<COMMENT><<EOF>>        { fprintf(stderr, "warning: comment opened on line %d is never closed\n", comment_start); return 0; }

"//".*                  { /* remove line comment */ }
^[ \t]*#[ \t]*include.*  { /* remove #include line (header names are not identifiers) */ }
^[ \t]*#[ \t]*[a-z]+     { /* remove directive word, e.g. #define (the macro name is kept) */ }
\"(\\.|[^\\"\n])*\"     { /* string contents are not identifiers */ }
\'(\\.|[^\\'\n])+\'     { /* char literal */ }
"@"{LETTER}+            { /* Java annotation such as @Override */ }
{DIGIT}+({LETTER}|{DIGIT}|".")*   { /* numbers like 10, 3.5f, 0x1F */ }
{LETTER}({LETTER}|{DIGIT})*       { record(yytext, yylineno); }
[ \t\r\n]+              { /* remove whitespace */ }
.                       { /* operators and punctuation */ }
%%

int main(int argc, char *argv[]) {
    if (argc == 2) {
        yyin = fopen(argv[1], "r");
        if (!yyin) { perror(argv[1]); return 1; }
    }
    yylex();

    printf("%-18s %-12s %s\n", "IDENTIFIER", "FIRST LINE", "OCCURRENCES");
    printf("%-18s %-12s %s\n", "----------", "----------", "-----------");
    for (int i = 0; i < count; i++)
        printf("%-18s %-12d %d\n", ids[i], first_line[i], uses[i]);
    printf("\nTotal distinct identifiers: %d\n", count);
    return 0;
}
