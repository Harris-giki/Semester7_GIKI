import java.util.ArrayList;

/**
 * Shapes demo. Comment words like hidden and secret
 * should NOT appear in the identifier list.
 */
public class Shapes {
    interface Shape { double area(); }

    static class Circle implements Shape {
        private final double radius;
        Circle(double radius) { this.radius = radius; }
        @Override
        public double area() { return Math.PI * radius * radius; }
    }

    public static void main(String[] args) {
        ArrayList<Shape> list = new ArrayList<>();
        list.add(new Circle(2.5));
        double totalArea = 0;   // running total
        for (Shape s : list) totalArea += s.area();
        System.out.println("Total area = " + totalArea);
    }
}
