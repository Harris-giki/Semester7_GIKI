int main() {
    int a = 5 @ 3;
    int b = a $ 2;
    /* this comment is never closed
    return 0;
}
