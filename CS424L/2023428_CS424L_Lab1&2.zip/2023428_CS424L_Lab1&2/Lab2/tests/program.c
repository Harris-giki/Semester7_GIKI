#include <stdio.h>
#define MAX 100

/* Multi-line comment:
   these numbers 999 and 3.14 and names like ghost
   must be ignored by the lexer */
struct point { int x, y; };

int scale(int value, int factor) {
    return value * factor - 1;     // binary minus: 1 is positive
}

int main(void) {
    int count = 0, limit = -1234;
    double ratio = 123.10, small = -0.5, big = 6.02e23;
    unsigned long mask = 0xFF, perm = 0755;
    struct point p = { 10, -20 };
    char letter = 'A';
    char *msg = "value 42 inside a string";

    for (int i = 0; i < MAX; i++) {
        if (i % 2 == 0 && count <= limit)
            count += scale(i, -3);
        else
            count = count-1;
    }
    p.x <<= 2;
    printf("%s %d %c\n", msg, count, letter);
    return 0;
}
