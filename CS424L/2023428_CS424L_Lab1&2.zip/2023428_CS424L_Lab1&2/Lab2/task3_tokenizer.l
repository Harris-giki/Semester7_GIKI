/* Lab 2 Task 3 - Muhammad Haris 2023428
   tokenizer for C. yylex() returns a token code and main calls it in a
   loop (like example 5 in the handout). ids and numbers are printed with
   their value, e.g. <ID,a>. unknown characters and unclosed comments
   are reported at the end.
   run: flex task3_tokenizer.l, gcc lex.yy.c -o task3, ./task3 file.c */
%option noyywrap
%option yylineno

%x COMMENT

%{
#include <stdio.h>
#include <string.h>

/* token codes (0 is reserved for end of input) */
enum {
    T_KEYWORD = 1, T_ID, T_NUM, T_FLOAT, T_STRING, T_CHAR, T_PREPROC,
    T_OP, T_NEWLINE, T_ERROR
};

/* for keywords and operators this holds the printable token name */
const char *tok_name;
int errors = 0;
char error_log[50][100];   /* lexical errors are listed after the token stream */

void lex_error(const char *msg, int line) {
    if (errors < 50)
        snprintf(error_log[errors], sizeof error_log[0], "line %d: %s", line, msg);
    errors++;
}
int comment_start = 0;

#define RET(code, name)  { tok_name = name; return code; }
%}

DIGIT   [0-9]
LETTER  [a-zA-Z_]
ID      {LETTER}({LETTER}|{DIGIT})*
EXP     [eE][+-]?{DIGIT}+

%%
 /* comments and whitespace */
"/*"                    { comment_start = yylineno; BEGIN(COMMENT); }
<COMMENT>"*/"           { BEGIN(INITIAL); }
<COMMENT>\n             { RET(T_NEWLINE, ""); }
<COMMENT>.              { }
<COMMENT><<EOF>>        { lex_error("unterminated comment", comment_start); return 0; }
"//".*                  { }
[ \t\r]+                { }
\n                      { RET(T_NEWLINE, ""); }
^[ \t]*#.*              { RET(T_PREPROC, "PREPROCESSOR"); }

 /* keywords */
"auto"      RET(T_KEYWORD, "AUTO")
"break"     RET(T_KEYWORD, "BREAK")
"case"      RET(T_KEYWORD, "CASE")
"char"      RET(T_KEYWORD, "CHAR")
"const"     RET(T_KEYWORD, "CONST")
"continue"  RET(T_KEYWORD, "CONTINUE")
"default"   RET(T_KEYWORD, "DEFAULT")
"do"        RET(T_KEYWORD, "DO")
"double"    RET(T_KEYWORD, "DOUBLE")
"else"      RET(T_KEYWORD, "ELSE")
"enum"      RET(T_KEYWORD, "ENUM")
"extern"    RET(T_KEYWORD, "EXTERN")
"float"     RET(T_KEYWORD, "FLOAT")
"for"       RET(T_KEYWORD, "FOR")
"goto"      RET(T_KEYWORD, "GOTO")
"if"        RET(T_KEYWORD, "IF")
"int"       RET(T_KEYWORD, "INT")
"long"      RET(T_KEYWORD, "LONG")
"register"  RET(T_KEYWORD, "REGISTER")
"return"    RET(T_KEYWORD, "RETURN")
"short"     RET(T_KEYWORD, "SHORT")
"signed"    RET(T_KEYWORD, "SIGNED")
"sizeof"    RET(T_KEYWORD, "SIZEOF")
"static"    RET(T_KEYWORD, "STATIC")
"struct"    RET(T_KEYWORD, "STRUCT")
"switch"    RET(T_KEYWORD, "SWITCH")
"typedef"   RET(T_KEYWORD, "TYPEDEF")
"union"     RET(T_KEYWORD, "UNION")
"unsigned"  RET(T_KEYWORD, "UNSIGNED")
"void"      RET(T_KEYWORD, "VOID")
"volatile"  RET(T_KEYWORD, "VOLATILE")
"while"     RET(T_KEYWORD, "WHILE")

 /* identifiers and literals */
{ID}                                    { return T_ID; }
0[xX][0-9a-fA-F]+[uUlL]*                { return T_NUM; }
{DIGIT}+"."{DIGIT}*{EXP}?[fFlL]?        { return T_FLOAT; }
"."{DIGIT}+{EXP}?[fFlL]?                { return T_FLOAT; }
{DIGIT}+{EXP}[fFlL]?                    { return T_FLOAT; }
{DIGIT}+[uUlL]*                         { return T_NUM; }
\"(\\.|[^\\"\n])*\"                     { return T_STRING; }
\'(\\.|[^\\'\n])+\'                     { return T_CHAR; }

 /* operators (longest first) */
"<<="   RET(T_OP, "SHL_ASSIGN")
">>="   RET(T_OP, "SHR_ASSIGN")
"..."   RET(T_OP, "ELLIPSIS")
"->"    RET(T_OP, "ARROW")
"++"    RET(T_OP, "INC")
"--"    RET(T_OP, "DEC")
"<<"    RET(T_OP, "SHL")
">>"    RET(T_OP, "SHR")
"<="    RET(T_OP, "LE")
">="    RET(T_OP, "GE")
"=="    RET(T_OP, "EQ")
"!="    RET(T_OP, "NE")
"&&"    RET(T_OP, "AND")
"||"    RET(T_OP, "OR")
"+="    RET(T_OP, "PLUS_ASSIGN")
"-="    RET(T_OP, "MINUS_ASSIGN")
"*="    RET(T_OP, "MULT_ASSIGN")
"/="    RET(T_OP, "DIV_ASSIGN")
"%="    RET(T_OP, "MOD_ASSIGN")
"&="    RET(T_OP, "AND_ASSIGN")
"|="    RET(T_OP, "OR_ASSIGN")
"^="    RET(T_OP, "XOR_ASSIGN")
"<"     RET(T_OP, "LT")
">"     RET(T_OP, "GT")
"="     RET(T_OP, "ASSIGN")
"+"     RET(T_OP, "PLUS")
"-"     RET(T_OP, "MINUS")
"*"     RET(T_OP, "MULT")
"/"     RET(T_OP, "DIV")
"%"     RET(T_OP, "MOD")
"!"     RET(T_OP, "NOT")
"&"     RET(T_OP, "BIT_AND")
"|"     RET(T_OP, "BIT_OR")
"^"     RET(T_OP, "XOR")
"~"     RET(T_OP, "BIT_NOT")
"?"     RET(T_OP, "QUESTION")
":"     RET(T_OP, "COLON")
"("     RET(T_OP, "LPAREN")
")"     RET(T_OP, "RPAREN")
"{"     RET(T_OP, "LBRACE")
"}"     RET(T_OP, "RBRACE")
"["     RET(T_OP, "LBRACKET")
"]"     RET(T_OP, "RBRACKET")
";"     RET(T_OP, "SEMI")
","     RET(T_OP, "COMMA")
"."     RET(T_OP, "DOT")

.       { return T_ERROR; }
%%

int main(int argc, char *argv[]) {
    if (argc == 2) {
        yyin = fopen(argv[1], "r");
        if (!yyin) { perror(argv[1]); return 1; }
    }

    int tok, tokens = 0, line = 1, at_line_start = 1;
    while ((tok = yylex()) != 0) {
        if (tok == T_NEWLINE) {
            if (!at_line_start) printf("\n");
            at_line_start = 1;
            continue;
        }
        if (at_line_start) { printf("%3d: ", yylineno); at_line_start = 0; }
        tokens++;
        switch (tok) {
            case T_KEYWORD:
            case T_OP:
            case T_PREPROC: printf("<%s>", tok_name); break;
            case T_ID:      printf("<ID,%s>", yytext); break;
            case T_NUM:     printf("<NUM,%s>", yytext); break;
            case T_FLOAT:   printf("<FLOAT,%s>", yytext); break;
            case T_STRING:  printf("<STRING,%s>", yytext); break;
            case T_CHAR:    printf("<CHAR,%s>", yytext); break;
            case T_ERROR:
                printf("<ERROR,%s>", yytext);
                {
                    char msg[40];
                    snprintf(msg, sizeof msg, "unknown character '%s'", yytext);
                    lex_error(msg, yylineno);
                }
                break;
        }
    }
    if (!at_line_start) printf("\n");
    printf("\nTokens: %d   Lexical errors: %d\n", tokens, errors);
    for (int i = 0; i < errors && i < 50; i++)
        printf("  error at %s\n", error_log[i]);
    return 0;
}
