/* Lab 2 Task 1 - Muhammad Haris 2023428
   finds numeric constants like 123, 123.10, -1234
   changes from lab 1: multi line comments are skipped using a start
   condition, and a minus sign is only counted as part of the number
   if the token before it was not a variable/number (so x-1 gives 1)
   run: flex task1_numbers.l, gcc lex.yy.c -o task1, ./task1 file.c */
%option noyywrap
%option yylineno

%x COMMENT

%{
#include <stdio.h>
#include <string.h>

int found = 0;
int prev_is_operand = 0;   /* 1 if the last token was a name, number or ')' / ']' */

void report(const char *kind, const char *text) {
    found++;
    printf("Line %-4d %-8s %s\n", yylineno, kind, text);
    prev_is_operand = 1;
}

/* text may start with '-' (and spaces). If the '-' is really a binary minus,
   strip it and report only the number. */
void number(const char *kind) {
    const char *p = yytext;
    if (*p == '-' && prev_is_operand) {
        p++;
        while (*p == ' ' || *p == '\t') p++;
        report(kind, p);
        return;
    }
    if (*p == '-') {                        /* unary minus: squeeze spaces */
        char buf[256];
        const char *q = p + 1;
        while (*q == ' ' || *q == '\t') q++;
        snprintf(buf, sizeof buf, "-%s", q);
        report(kind, buf);
        return;
    }
    report(kind, p);
}
%}

DIGIT   [0-9]
INT     {DIGIT}+
EXP     [eE][+-]?{DIGIT}+
FSUF    [fFlL]
ISUF    ([uU][lL]{0,2}|[lL]{1,2}[uU]?)
NEG     ("-"[ \t]*)?

%%
"/*"                    { BEGIN(COMMENT); }
<COMMENT>"*/"           { BEGIN(INITIAL); }
<COMMENT>.|\n           { /* skip comment text */ }

"//".*                  { /* skip line comment */ }
\"(\\.|[^\\"\n])*\"     { prev_is_operand = 1; /* skip string */ }
\'(\\.|[^\\'\n])+\'     { prev_is_operand = 1; /* skip char literal */ }
[a-zA-Z_$][a-zA-Z0-9_$]* { prev_is_operand = 1; /* identifier */ }

{NEG}0[xX][0-9a-fA-F]+{ISUF}?           { number("HEX"); }
{NEG}{INT}"."{DIGIT}*{EXP}?{FSUF}?      { number("FLOAT"); }
{NEG}"."{DIGIT}+{EXP}?{FSUF}?           { number("FLOAT"); }
{NEG}{INT}{EXP}{FSUF}?                  { number("FLOAT"); }
{NEG}0[0-7]+{ISUF}?                     { number("OCTAL"); }
{NEG}{INT}{ISUF}?                       { number("INTEGER"); }

[)\]]                   { prev_is_operand = 1; }
[ \t\r\n]+              { /* whitespace does not change context */ }
.                       { prev_is_operand = 0; /* any operator / punctuation */ }
%%

int main(int argc, char *argv[]) {
    if (argc == 2) {
        yyin = fopen(argv[1], "r");
        if (!yyin) { perror(argv[1]); return 1; }
    }
    printf("%-9s %-8s %s\n", "LINE", "TYPE", "CONSTANT");
    yylex();
    printf("\nTotal numerical constants found: %d\n", found);
    return 0;
}
